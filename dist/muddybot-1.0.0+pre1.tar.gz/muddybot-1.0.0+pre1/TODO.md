# Twitch-bot

This is a simple twitch bot to handle wordle on wheels for [mudflaps](https://twitch.tv/mud_flaps123)

### Todo

### In progress

- [ ] Make documentation for the project
- [ ] Release version 1.0.0

### Completed

- [x] Change the name of the bot
