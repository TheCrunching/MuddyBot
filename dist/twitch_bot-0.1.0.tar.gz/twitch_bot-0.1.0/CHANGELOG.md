# Changelog

## [0.1.0] - 2025-06-06

_Initial release_
