# Twitch-bot

This is a simple twitch bot to handle wordle on wheels for [mudflaps](https://twitch.tv/mud_flaps123)

### Todo

### In progress

- [ ] Release version 1.0.0

### Completed

- [x] Make documentation for the project
- [x] Change the name of the bot
