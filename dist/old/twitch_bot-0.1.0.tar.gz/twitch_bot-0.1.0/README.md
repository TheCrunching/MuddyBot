# A twitch bot

This is a twitch bot I made for Mud Flaps!
