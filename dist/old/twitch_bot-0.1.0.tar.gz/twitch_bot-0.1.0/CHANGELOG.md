# Changelog

## [0.1.0] - 2025-06-06

_Initial release_

[0.1.0]: https://github.com/TheCrunching/python-twitch-bot/releases/tag/v0.1.0
